
IF EXISTS (SELECT * FROM SYSOBJECTS WHERE name LIKE 'syspublications')
AND EXISTS(	SELECT * FROM GLOBAL_REGISTRY
			WHERE REGISTRY_KEY = 'REPLICATION_PUBLICATION_NAME'
			AND VALUE1 IS NOT NULL
			AND VALUE1 <> '')
BEGIN

	-- Get the publication name
	DECLARE @publicationName NVARCHAR(255)
	SET @publicationName = (SELECT VALUE1 FROM GLOBAL_REGISTRY WHERE REGISTRY_KEY = 'REPLICATION_PUBLICATION_NAME')
	
	-- Check for valid Publication
	IF @publicationName <> ''
	BEGIN
		RAISERROR('Refreshing Subscriptions for Publication: %s', 0, 1, @publicationName) WITH NOWAIT
	
		-- Refresh subscriptions to have the articles prepped for the incremental snapshot
		EXEC sp_refreshsubscriptions @publicationName
		
		RAISERROR('Starting the Snapshot Agent Job for Publication: %s', 0, 1, @publicationName) WITH NOWAIT
		
		-- Start the Snapshot Job
		EXEC sp_startpublication_snapshot @publicationName
		
		RAISERROR('Monitor the Snapshot progress through Replication Monitor', 0, 1) WITH NOWAIT
			
	END
END
ELSE
BEGIN
	RAISERROR('No Publication found!', 0, 1) WITH NOWAIT
END