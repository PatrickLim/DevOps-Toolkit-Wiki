Set Nocount On
GO

If exists (select * from dbo.sysobjects where id = object_id(N'[dbo].GRANT_RIGHTS') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	Drop Procedure GRANT_RIGHTS
GO

Create Procedure [dbo].GRANT_RIGHTS (@SP_OR_TABLE varchar (255))
AS

declare @cmd varchar(255)

if exists (select * from dbo.sysobjects where id = object_id(@SP_OR_TABLE) and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN

	set @cmd = 'GRANT  EXECUTE  ON ' + @SP_OR_TABLE + ' TO [Public]' 
	exec (@cmd)

END
ELSE IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(@SP_OR_TABLE) AND type in (N'U'))
BEGIN

	set @cmd = 'GRANT  REFERENCES ,  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON ' + @SP_OR_TABLE + ' TO [Public]' 
	exec (@cmd)

	set @cmd = 'GRANT  REFERENCES ,  SELECT  ON ' + @SP_OR_TABLE + ' TO [Public]' 
	exec (@cmd)

	
END
ELSE 
BEGIN
	raiserror ('Object %s is not a stored procedure or table!', 11, 1, @SP_OR_TABLE)
END

GO

-- <INSERT SCRIPTS BELOW> --
-------------------------------------------
--BEGIN CAS-37764
-------------------------------------------
RAISERROR ('Begin CAS-37764', 0, 1) WITH NOWAIT
GO

IF(NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE id = OBJECT_ID(N'[PURGE_TABLES]') AND OBJECTPROPERTY(id, N'IsUserTable')=1))
BEGIN

	CREATE TABLE PURGE_TABLES
	(TABLE_NAME VARCHAR(128) NOT NULL,
	COMMAND VARCHAR(128) NOT NULL,
	MAX_DAYS INT NOT NULL,
	ENABLE_FLG tinyint NOT NULL
	CONSTRAINT [PK_PURGE_TABLES] PRIMARY KEY CLUSTERED 
	(
		[TABLE_NAME] ASC
	)	WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	INSERT INTO PURGE_TABLES (TABLE_NAME, COMMAND, MAX_DAYS, ENABLE_FLG)
	VALUES ('SKIP_RECORD', 'PURGE_SKIP_RECORD_V2015_Q1_V1', 30, 0)
	INSERT INTO PURGE_TABLES (TABLE_NAME, COMMAND, MAX_DAYS, ENABLE_FLG)
	VALUES ('TRANSACTIONS', 'PURGE_TRANSACTIONS_V2015_Q1_V1', 30, 0)

	IF EXISTS ( SELECT * FROM MSDB.DBO.SYSJOBS J
				JOIN	MSDB.DBO.SYSJOBSTEPS JS	ON JS.JOB_ID = J.JOB_ID 
				JOIN	MASTER.DBO.SYSSERVERS S ON S.SRVID = J.ORIGINATING_SERVER_ID
				WHERE	J.NAME LIKE N'%Purge Tables%' AND
						JS.STEP_NAME LIKE N'%Purge_Sislnk%' AND
				JS.DATABASE_NAME = DB_NAME() AND J.[ENABLED] = 1)
	BEGIN
		DECLARE @JOB SYSNAME
		DECLARE @DAYS INT
		
		SELECT @DAYS = ISNULL(VALUE1, 7)
		FROM GLOBAL_REGISTRY WHERE REGISTRY_KEY = 'PURGE_NOTIFICATIONS_DAYS'

		SELECT @JOB = J.NAME
		FROM MSDB.DBO.SYSJOBS J
		JOIN	MSDB.DBO.SYSJOBSTEPS JS	ON JS.JOB_ID = J.JOB_ID 
		JOIN	MASTER.DBO.SYSSERVERS S ON S.SRVID = J.ORIGINATING_SERVER_ID
		WHERE	J.NAME LIKE N'%Purge Tables%' AND
		JS.DATABASE_NAME = DB_NAME() AND J.[ENABLED] = 1

		EXEC MSDB.DBO.SP_UPDATE_JOB @JOB_NAME=@JOB, @ENABLED = 0

		UPDATE PURGE_TABLES
		SET ENABLE_FLG = 1, MAX_DAYS = @DAYS
		WHERE TABLE_NAME = 'TRANSACTIONS'
	END

END
GO

EXEC GRANT_RIGHTS '[dbo].[PURGE_TABLES]'
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ICS_PURGE_SISLNK_TABLES_V2015_Q1_V1]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	SET NOEXEC ON
GO
CREATE PROCEDURE [dbo].[ICS_PURGE_SISLNK_TABLES_V2015_Q1_V1]
AS
BEGIN

	DECLARE @SQL NVARCHAR(255)
	DECLARE @COMMAND VARCHAR(128)
	DECLARE @MAX_DAYS INT

	DECLARE PURGE_CURSOR CURSOR
	FOR
		SELECT COMMAND, MAX_DAYS
		FROM PURGE_TABLES
		WHERE ENABLE_FLG = 1
	FOR READ ONLY

	OPEN PURGE_CURSOR

	FETCH NEXT FROM PURGE_CURSOR INTO @COMMAND, @MAX_DAYS

	WHILE (@@FETCH_STATUS >= 0)
	BEGIN
		
		SELECT @SQL = 'EXEC ' + @COMMAND + ' ' + CAST(@MAX_DAYS AS VARCHAR(5))

		BEGIN TRY
			EXEC SP_EXECUTESQL @SQL
		END TRY
		BEGIN CATCH
			SELECT @COMMAND = @COMMAND + ' failed to complete.'
			RAISERROR(@COMMAND,16, 1) WITH NOWAIT
			RETURN
		END CATCH

		FETCH NEXT FROM PURGE_CURSOR INTO @COMMAND, @MAX_DAYS
	END
	CLOSE PURGE_CURSOR
	DEALLOCATE PURGE_CURSOR

END
GO

SET NOEXEC OFF
GO

EXEC GRANT_RIGHTS '[dbo].[ICS_PURGE_SISLNK_TABLES_V2015_Q1_V1]'
GO

IF NOT EXISTS ( SELECT * FROM MSDB.DBO.SYSJOBS J
				JOIN	MSDB.DBO.SYSJOBSTEPS JS	ON JS.JOB_ID = J.JOB_ID 
				JOIN	MASTER.DBO.SYSSERVERS S ON S.SRVID = J.ORIGINATING_SERVER_ID
				WHERE	J.NAME LIKE N'%ICS_Purge_Sislnk_Tables%' AND
				JS.DATABASE_NAME = DB_NAME())
BEGIN

	BEGIN TRANSACTION
	
	RAISERROR ('Adding ICS_Purge_Sislnk_Tables_V2015_Q1_V1 Job', 0, 1) WITH NOWAIT
	DECLARE @dbName VARCHAR(128)
	SELECT @dbName = DB_NAME()
	DECLARE @ReturnCode INT
	SELECT @ReturnCode = 0

	DECLARE @jobId BINARY(16)
	EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ICS_Purge_Sislnk_Tables_V2015_Q1_V1', 
			@enabled=1, 
			@notify_level_eventlog=0, 
			@notify_level_email=0, 
			@notify_level_netsend=0, 
			@notify_level_page=0, 
			@delete_level=0, 
			@description=N'This job purges history from various ICS history tables on the Sislnk database.', 
			@category_name=N'[Uncategorized (Local)]', 
			@job_id = @jobId OUTPUT
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
	/****** Object:  Step [Purge Tables]    Script Date: 7/15/2016 1:42:16 PM ******/
	EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge Sislnk Tables', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, @subsystem=N'TSQL', 
			@command=N'EXEC [dbo].[ICS_PURGE_SISLNK_TABLES_V2015_Q1_V1]', 
			@database_name= @dbName, 
			@flags=0
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
	EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
	EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'ICS Purge Sislnk Tables Schedule', 
			@enabled=1, 
			@freq_type=8, 
			@freq_interval=1, 
			@freq_subday_type=1, 
			@freq_subday_interval=0, 
			@freq_relative_interval=0, 
			@freq_recurrence_factor=1, 
			@active_start_date=20160715, 
			@active_end_date=99991231, 
			@active_start_time=33000, 
			@active_end_time=235959
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
	EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
	COMMIT TRANSACTION
	GOTO EndSave
	QuitWithRollback:
		IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
	EndSave:
		DECLARE @JOB_NAME VARCHAR(255)
		SELECT @JOB_NAME = 'ICS_Purge_Sislnk_Tables_V2015_Q1_V1 ' + @dbName

		EXEC msdb.dbo.sp_update_job @JOB_NAME= N'ICS_Purge_Sislnk_Tables_V2015_Q1_V1', @NEW_NAME = @JOB_NAME
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[PURGE_SKIP_RECORD_V2015_Q1_V1]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	SET NOEXEC ON
GO
CREATE PROCEDURE [dbo].[PURGE_SKIP_RECORD_V2015_Q1_V1] (@MAX_DAYS INT)
AS
BEGIN

	DELETE FROM SKIP_RECORD 
	WHERE DATEDIFF(DAY, SKIP_DATE, GETDATE()) > @MAX_DAYS

END
GO
SET NOEXEC OFF
GO

EXEC GRANT_RIGHTS '[dbo].[PURGE_SKIP_RECORD_V2015_Q1_V1]'
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[PURGE_TRANSACTIONS_V2015_Q1_V1]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	SET NOEXEC ON
GO
CREATE PROCEDURE [dbo].[PURGE_TRANSACTIONS_V2015_Q1_V1] (@MAX_DAYS INT)
AS
BEGIN

	WHILE EXISTS(	SELECT 1 FROM TRANSACTIONS 
					WHERE DATEDIFF(DAY, TRANSMITTED, GETDATE()) > @MAX_DAYS)
	BEGIN

		DELETE FROM TRANSACTIONS WITH (ROWLOCK)
		WHERE RECORD_NUM IN 
			(SELECT TOP 5000 RECORD_NUM FROM TRANSACTIONS WITH (NOLOCK) 
			WHERE DATEDIFF(DAY, TRANSMITTED, GETDATE()) > @MAX_DAYS) 
	END

END
GO
SET NOEXEC OFF
GO

EXEC GRANT_RIGHTS '[dbo].[PURGE_TRANSACTIONS_V2015_Q1_V1]'
GO

RAISERROR ('End CAS-37764', 0, 1) WITH NOWAIT
GO
-------------------------------------------
--END CAS-37764
-------------------------------------------
-------------------------------------------
--BEGIN CAS-51580
-------------------------------------------
RAISERROR ('Begin CAS-51580', 0, 1) WITH NOWAIT
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[TRANSACTIONS_STATUS_V2015_Q1_V1]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	SET NOEXEC ON
GO
CREATE PROCEDURE [dbo].[TRANSACTIONS_STATUS_V2015_Q1_V1] (@CLIENT_NUM CLIENT_NUM, @INBOUND TINYINT, @MINUTES INT)
AS
BEGIN
	SET NOCOUNT ON;
	
	/*DEBUG****************
	DECLARE @CLIENT_NUM CLIENT_NUM
	DECLARE @INBOUND TINYINT
	DECLARE @MINUTES INT

	SET @CLIENT_NUM = 300
	SET @INBOUND = 0
	SET @MINUTES = 5
	***************DEBUG*/

	IF @INBOUND = 0
	BEGIN
		IF NOT EXISTS(	SELECT 1 FROM TRANSACTIONS 
						WHERE DESTINATION = @CLIENT_NUM
						AND TRANSMITTED > DATEADD(MINUTE, -@MINUTES, GETDATE())
						AND TRANSMITTED < GETDATE() )
			SELECT DISTINCT T.DESTINATION CLIENT_NUM
			FROM TRANSACTIONS T
			WHERE T.DESTINATION = @CLIENT_NUM
	END
	ELSE
	BEGIN
		IF NOT EXISTS(	SELECT 1 FROM TRANSACTIONS 
						WHERE CLIENT_NUM =  @CLIENT_NUM
						AND TRANSMITTED > DATEADD(MINUTE, -@MINUTES, GETDATE())
						AND TRANSMITTED < GETDATE())
			SELECT DISTINCT T.CLIENT_NUM
			FROM TRANSACTIONS T
			WHERE T.CLIENT_NUM = @CLIENT_NUM
	END

	SET NOCOUNT OFF;
END
GO

SET NOEXEC OFF
GO

EXEC GRANT_RIGHTS '[dbo].[TRANSACTIONS_STATUS_V2015_Q1_V1]'
GO

RAISERROR ('End CAS-51580', 0, 1) WITH NOWAIT
GO
-------------------------------------------
--END CAS-51580
-------------------------------------------
-------------------------------------------
--BEGIN NS-115145
-------------------------------------------
RAISERROR ('Begin NS-115145', 0, 1) WITH NOWAIT
GO
IF NOT EXISTS (SELECT * FROM record_types WHERE record_type = '2702')
BEGIN
	INSERT INTO record_types(record_type, record_name, description)
	VALUES('2702', 'HL7MDMT02', 'HL7 Message T02: Scan Image (Image Data)')
END

RAISERROR ('End NS-115145', 0, 1) WITH NOWAIT
GO
-------------------------------------------
--END NS-115145
-------------------------------------------
-- <INSERT SCRIPTS ABOVE> --

DROP PROCEDURE GRANT_RIGHTS
GO

-- Version Update for the syslnk database
RAISERROR ('Updating Version data',0,1) WITH NOWAIT
GO

declare @VERSION varchar(6)
declare @BUILD varchar(6)
declare @RELEASE varchar(30)

Select @VERSION = '2019.1'
Select @BUILD = 'Dev' --Insert Date in YYMMDD when moving to Patch
Select @RELEASE = '2019.1.INF-0'

RAISERROR ('Inserted release: %s build %s ', 0, 1, @RELEASE, @BUILD)

Insert Into Version Select @VERSION, @BUILD, 
getdate(), suser_sname(), host_name(), 'ICS Database @ ' + @RELEASE + ' Build ' + @BUILD
go

DECLARE @database_name varchar(255)
SET @database_name = db_name()
RAISERROR ('Inserted into: %s database',0,1,@database_name)
GO

DECLARE @date varchar(255)
SET @date = CONVERT(VARCHAR,GETDATE())
RAISERROR ('Script complete: %s',0,1,@date) WITH NOWAIT
GO

Set Nocount Off
GO
