/**
	This is the first script that should be executed when upgarding to RCM Cloud/Classic 2020.1.
	The GLOBAL_REGISTRY REPLICATION_PUBLICATION_NAME key MUST be set to the replication name for InsightCS.
	After running this script, the migration process should be executed for the ROLE_ID.
	Once that completes, the standard script can be executed (InsightCS 2020.1.sql)

	// Example script if not set (change VALUE1 to replication package name)
	UPDATE GLOBAL_REGISTRY SET VALUE1='IcsDevCopyPkg' WHERE REGISTRY_KEY = 'REPLICATION_PUBLICATION_NAME'
**/
SET NOCOUNT ON

RAISERROR ('BEGIN NS-111907 - PRE-UDT PRODUCTION script. Run prior to InsightCS ROLE_MSTR migration process.', 0, 1) WITH NOWAIT
GO

-------------------------------------------------------------------------
-- Drop an Article from the Subscription, then drop from the Publication
-------------------------------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].DROP_ARTICLE') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[DROP_ARTICLE]
GO

CREATE PROCEDURE [dbo].[DROP_ARTICLE] (@articleName varchar (255))
AS
BEGIN
	IF EXISTS (SELECT * FROM SYSOBJECTS WHERE name LIKE 'syspublications')
	AND EXISTS(	SELECT * FROM GLOBAL_REGISTRY
				WHERE REGISTRY_KEY = 'REPLICATION_PUBLICATION_NAME'
				AND VALUE1 IS NOT NULL
				AND VALUE1 <> '')
	BEGIN
		-- Check if [dbo]. tag exists on the SP_OR_TABLE name
		IF (CHARINDEX('[dbo].[', @articleName) > 0)
		BEGIN
			-- FORMAT: [dbo].[xxxx]
			
			-- Remove owner information
			SET @articleName = REPLACE(@articleName, '[dbo].[', '')
			-- Remove trailing ']'
			SET @articleName = LEFT(@articleName, LEN(@articleName) - 1)
		END
		ELSE IF (CHARINDEX('[dbo].', @articleName) > 0)
		BEGIN
			-- FORMAT: [dbo].xxxx
			
			-- Remove owner information
			SET @articleName = REPLACE(@articleName, '[dbo].', '')
		END
		
		-- Verify it is an existing article
		IF EXISTS(SELECT * FROM SYSARTICLES WHERE NAME = @articleName) OR EXISTS(SELECT * FROM SYSSCHEMAARTICLES WHERE NAME = @articleName)
		BEGIN
		
			-- Get publication Name
			DECLARE @publicationName SYSNAME
			SET @publicationName = (SELECT VALUE1 FROM GLOBAL_REGISTRY WHERE REGISTRY_KEY = 'REPLICATION_PUBLICATION_NAME')
			
			-- Get Subscriber Server Name
			DECLARE @subscriberName SYSNAME
			SET @subscriberName = (SELECT DISTINCT SRVNAME FROM SYSSUBSCRIPTIONS)
			
			-- If article exists in Subscription
			IF EXISTS(	SELECT Subscriber=syssubscriptions.srvname, article_name=name
						FROM syssubscriptions 
						INNER JOIN sysarticles on syssubscriptions.artid=sysarticles.artid
						WHERE name = @articleName)
			OR
			
			EXISTS (	SELECT Subscriber=syssubscriptions.srvname, article_name=name
						FROM syssubscriptions 
						INNER JOIN sysschemaarticles on syssubscriptions.artid=sysschemaarticles.artid
						WHERE name = @articleName)
			BEGIN
				-- Drop the article from the Subscription
				EXEC sp_dropsubscription	@publication = @publicationName,
											@article = @articleName,
											@subscriber = @subscriberName
				RAISERROR('Article ''%s'' has been dropped from Subscription.', 0, 1, @articleName) WITH NOWAIT
			END
			
			
			-- Drop the article from the Publication							
			EXEC sp_droparticle	@publication = @publicationName,
								@article = @articleName,
								@force_invalidate_snapshot = 1
								
			RAISERROR('Article ''%s'' has been dropped from Publication.', 0, 1, @articleName) WITH NOWAIT
			
		END
	END
END
GO


---------------------------------------------------------------------------------------
-- Add an Article to the Snapshot if Snapshot exists as well as article does not exist
---------------------------------------------------------------------------------------
If exists (select * from dbo.sysobjects where id = object_id(N'[dbo].ADD_NEW_ARTICLE') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	Drop Procedure ADD_NEW_ARTICLE
GO

CREATE PROCEDURE [dbo].ADD_NEW_ARTICLE (@SP_OR_TABLE varchar (255)) AS
BEGIN

	DECLARE @MessageDisplay		NVARCHAR(250)
	SET @MessageDisplay = ''
	
	IF EXISTS (SELECT * FROM SYSOBJECTS WHERE name LIKE 'syspublications')
	AND EXISTS(	SELECT * FROM GLOBAL_REGISTRY
				WHERE REGISTRY_KEY = 'REPLICATION_PUBLICATION_NAME'
				AND VALUE1 IS NOT NULL
				AND VALUE1 <> '')
	BEGIN
		
		-- drop all articles
		DECLARE @publicationName	NVARCHAR(255)
		DECLARE @articleName		NVARCHAR(255)
		DECLARE @articleType		NVARCHAR(2)
		DECLARE @articleInsCmd		NVARCHAR(512)
		DECLARE @articleDelCmd		NVARCHAR(512)
		DECLARE @articleUpdCmd		NVARCHAR(512)
		DECLARE @typeCmd			NVARCHAR(32)
		DECLARE @tableIdentityCmd	NVARCHAR(10)
		
		
		-- Check if [dbo]. tag exists on the SP_OR_TABLE name
		IF (CHARINDEX('[dbo].[', @SP_OR_TABLE) > 0)
		BEGIN
			-- Remove owner information
			SET @SP_OR_TABLE = REPLACE(@SP_OR_TABLE, '[dbo].[', '')
			-- Remove trailing ']'
			SET @SP_OR_TABLE = LEFT(@SP_OR_TABLE, LEN(@SP_OR_TABLE) - 1)
		END

		SET @MessageDisplay = 'Article ' + @SP_OR_TABLE + ' already part of Snapshot, no need to add.'
	
		DECLARE PublicationList CURSOR
		FOR
		SELECT VALUE1 FROM GLOBAL_REGISTRY WHERE REGISTRY_KEY = 'REPLICATION_PUBLICATION_NAME'
		
		OPEN PublicationList
		FETCH NEXT FROM PublicationList INTO @publicationName
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @articleName = s.name, @articleType= s.type FROM SYSOBJECTS s, ICS_REPLICATION ir
			WHERE s.TYPE = ir.OBJECT_TYPE
			AND (s.TYPE = N'U' or s.TYPE = N'P' or  s.TYPE = N'V' or s.TYPE=N'FN' or s.TYPE=N'TF') 
			AND s.CATEGORY <> 2
			AND ir.ENABLE_FLG = 1
			AND s.name = @SP_OR_TABLE

			IF @articleName IS NOT NULL
			BEGIN
				-- Drop articles
				IF NOT EXISTS(SELECT * FROM ICS_EXCLUDE_REPLICATION WHERE OBJECT_NAME = @articleName AND OBJECT_TYPE =  @articleType)
				BEGIN
					IF(@articleType = N'U')
					BEGIN
						--Verify table has primary key
						IF(EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC WHERE TC.constraint_type = 'Primary Key' and TABLE_NAME = @articleName) AND NOT EXISTS (SELECT * FROM SYSARTICLES WHERE NAME = @articleName))
						BEGIN
							SET @articleInsCmd = N'CALL [dbo].[sp_MSins_dbo' + @articleName + ']'
							SET @articleDelCmd = N'CALL [dbo].[sp_MSdel_dbo' + @articleName + ']'
							SET @articleUpdCmd = N'SCALL [dbo].[sp_MSupd_dbo' + @articleName + ']'
							
							IF(EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = @articleName AND OBJECTPROPERTY(object_id(NAME), 'TableHasIdentity') = 1))
							BEGIN
								SET @tableIdentityCmd = N'manual'
							END
							ELSE
							BEGIN
								SET @tableIdentityCmd = N'none'
							END
							
							exec sp_addarticle 
									@publication = @publicationName, 
									@article = @articleName, 
									@source_owner = N'dbo', 
									@source_object = @articleName, 
									@type = N'logbased', 
									@description = N'', 
									@creation_script = N'', 
									@pre_creation_cmd = N'drop', 
									@schema_option = 0x00000000080350DF, 
									@identityrangemanagementoption = @tableIdentityCmd, 
									@destination_table = @articleName, 
									@destination_owner = N'dbo', 
									@status = 24, 
									@vertical_partition = N'false', 
									@ins_cmd = @articleInsCmd, 
									@del_cmd = @articleDelCmd, 
									@upd_cmd = @articleUpdCmd

							SET @MessageDisplay = 'Adding New Article ' + @SP_OR_TABLE + ' to Database Snapshot!'
						END
					END
					ELSE
					BEGIN
						
						IF(@articleType = N'P')
						BEGIN
							SET @typeCmd = N'proc schema only'
						END 
						ELSE IF(@articleType = N'V')
						BEGIN
							IF(EXISTS (SELECT *  from sysobjects where type=N'V' and name = @articleName and OBJECTPROPERTY(id, N'IsSchemaBound') = 0))
							BEGIN
								SET @typeCmd = N'view schema only'
							END
							ELSE
							BEGIN
								SET @typeCmd = N'indexed view schema only'
							END
						END 
						ELSE IF(@articleType = N'TF' OR @articleType = N'FN')
						BEGIN
							SET @typeCmd = N'func schema only'
						END
						
						--verify encryption.
						IF(EXISTS (SELECT * FROM SYSOBJECTS SO INNER JOIN SYS.SQL_MODULES SM ON SO.id = SM.object_id WHERE SM.definition IS NOT NULL AND SO.name = @articleName))
						BEGIN
							IF (NOT EXISTS(SELECT * FROM sysschemaarticles WHERE name = @articleName))
							BEGIN
								EXEC sp_addarticle 
									@publication = @publicationName, 
									@article = @articleName, 
									@source_owner = N'dbo', 
									@source_object = @articleName, 
									@type = @typeCmd,
									@description = N'',
									@creation_script = N'', 
									@pre_creation_cmd = N'drop', 
									@schema_option = 0x0000000008000001, 
									@destination_table = @articleName, 
									@destination_owner = N'dbo', 
									@status = 16
							
								SET @MessageDisplay = 'Adding New Article ' + @SP_OR_TABLE + ' to Database Snapshot!'
							END --END article existence check
						END
					END
				END
			END
			ELSE
			BEGIN
				Select @MessageDisplay = 'Stored procedure or table ' + @SP_OR_TABLE + ' does not exist.  Article cannot be added to the snapshot.'
			END
			
			FETCH NEXT FROM PublicationList INTO @publicationName
		END
		
		CLOSE PublicationList
		DEALLOCATE PublicationList
	END

	IF @MessageDisplay <> '' AND @MessageDisplay IS NOT NULL
	BEGIN
		RAISERROR(@MessageDisplay,0,1) WITH NOWAIT
	END

END
GO


/*
** These need to be dropped prior to creating replication (or excluded) as they're not supported in 2019.
*/
IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE NAME = 'ADM_DISXCL3_V2008_Q2')
BEGIN
	RAISERROR ('     Dropping invalid SPs.', 0, 1) WITH NOWAIT
	EXEC DROP_ARTICLE 'ADM_DISXCL3_V2008_Q2'
	EXEC DROP_ARTICLE 'ASP_CHARGE_SHEET_DETAIL_INSERT'
	EXEC DROP_ARTICLE 'BILLING_CHARGE_V4'
	EXEC DROP_ARTICLE 'CENSINQ_BEDBOARD_SEARCH_V2009_Q1'
	EXEC DROP_ARTICLE 'COMDLG_NOTE_SEARCH_V2008_Q1'
	EXEC DROP_ARTICLE 'EDI_270_CONVERT_WORK_V2013_Q1_V1'
	EXEC DROP_ARTICLE 'F1500_SELECTION_V2007_Q4'
	EXEC DROP_ARTICLE 'F1500_SELECTION_V2007_Q4_V2'
	EXEC DROP_ARTICLE 'MR_VISIT_SEARCH_ON_DOB_V2015_Q2_V1'
	EXEC DROP_ARTICLE 'MR_VISIT_SEARCH_ON_VISIT_V2016_Q1_V3'
	EXEC DROP_ARTICLE 'NIGHTLY_PROCESSING_SCORECARD_QUEUE_SNAPSHOT_V2017_Q2_V1'
	EXEC DROP_ARTICLE 'PATDETAIL_RETRIEVE_VISITS_BY_MRN_V2011'
	EXEC DROP_ARTICLE 'PATIENT_SEARCH_V2008_Q1_3'
	EXEC DROP_ARTICLE 'PATIENT_SEARCH_V2008_Q1_4'
	EXEC DROP_ARTICLE 'RPT_CHARGEMASTER'
	EXEC DROP_ARTICLE 'UB92_DETAIL_SELECTION_V2007_Q4'
	EXEC DROP_ARTICLE 'UB92_DETAIL_SELECTION_V2007_Q4_V2'
	EXEC DROP_ARTICLE 'UB92_DETAIL_SELECTION_V2007_Q4_V3'
	EXEC DROP_ARTICLE 'UB92_DETAIL_SELECTION_V2008_Q2_V1'
	EXEC DROP_ARTICLE 'UB92_DETAIL_SELECTION_V2008_Q3_V1'
	EXEC DROP_ARTICLE 'UB92_DETAIL_SELECTION_V2008_Q3_V2'
	EXEC DROP_ARTICLE 'UB92_DETAIL_SELECTION_V2008_Q3_V3'
	EXEC DROP_ARTICLE 'UB92_SURGEON_V2007_Q2_V2'

	DROP PROCEDURE ADM_DISXCL3_V2008_Q2
	DROP PROCEDURE ASP_CHARGE_SHEET_DETAIL_INSERT
	DROP PROCEDURE BILLING_CHARGE_V4
	DROP PROCEDURE CENSINQ_BEDBOARD_SEARCH_V2009_Q1
	DROP PROCEDURE COMDLG_NOTE_SEARCH_V2008_Q1
	DROP PROCEDURE EDI_270_CONVERT_WORK_V2013_Q1_V1
	DROP PROCEDURE F1500_SELECTION_V2007_Q4
	DROP PROCEDURE F1500_SELECTION_V2007_Q4_V2
	DROP PROCEDURE MR_VISIT_SEARCH_ON_DOB_V2015_Q2_V1
	DROP PROCEDURE MR_VISIT_SEARCH_ON_VISIT_V2016_Q1_V3
	DROP PROCEDURE NIGHTLY_PROCESSING_SCORECARD_QUEUE_SNAPSHOT_V2017_Q2_V1
	DROP PROCEDURE PATDETAIL_RETRIEVE_VISITS_BY_MRN_V2011
	DROP PROCEDURE PATIENT_SEARCH_V2008_Q1_3
	DROP PROCEDURE PATIENT_SEARCH_V2008_Q1_4
	DROP PROCEDURE RPT_CHARGEMASTER
	DROP PROCEDURE UB92_DETAIL_SELECTION_V2007_Q4
	DROP PROCEDURE UB92_DETAIL_SELECTION_V2007_Q4_V2
	DROP PROCEDURE UB92_DETAIL_SELECTION_V2007_Q4_V3
	DROP PROCEDURE UB92_DETAIL_SELECTION_V2008_Q2_V1
	DROP PROCEDURE UB92_DETAIL_SELECTION_V2008_Q3_V1
	DROP PROCEDURE UB92_DETAIL_SELECTION_V2008_Q3_V2
	DROP PROCEDURE UB92_DETAIL_SELECTION_V2008_Q3_V3
	DROP PROCEDURE UB92_SURGEON_V2007_Q2_V2
END
GO

/**
	If the table has already been converted to remove teh identity from the column, do not run conversion script.
**/
IF (SELECT IS_IDENTITY FROM SYS.COLUMNS WHERE NAME = 'ROLE_ID' AND OBJECT_ID = OBJECT_ID('ROLE_MSTR')) != 1
BEGIN
	RAISERROR ('     The ROLE_MSTR table has already been converted for the ROLE_ID, the script will not be executed.', 0, 1) WITH NOWAIT
	RETURN
END

-- Alter the ROLE_MSTR table to drop the identity field/pk.
RAISERROR('     Altering ROLE_MSTR in preparation for migration...', 0, 1) WITH NOWAIT
/**
	1. Remove all foreign keys that point to the ROLE_MSTR table
	2. Script the new table to be created; rename everything e.g. 'MyTable2', 'MyIndex2', etc, removing the IDENTITY specification.
	3. You should now have two "identical"-ish tables, one full, the other empty with no IDENTITY.
	4. Run ALTER TABLE [ROLE_MSTR] SWITCH TO [ROLE_MSTR2]
	5. Now your original table will be empty and the new one will have the data. You have switched the metadata for the two tables (instant).
	6. Rename the original (now-empty table), exec sys.sp_rename to rename the various schema objects back to the original names, and then you can recreate your foreign keys.
**/


RAISERROR('			Dropping foreign keys to ROLE_MSTR...', 0, 1) WITH NOWAIT

-- Some foriegn keys are not named and must be retrieved dynamcially. When added back, they are named properly.
DECLARE @keyName VARCHAR(100)
SELECT @keyName = NULL
SELECT @keyName = NAME
FROM	SYS.FOREIGN_KEYS 
WHERE	PARENT_OBJECT_ID = OBJECT_ID('ROLE_SEC_RIGHT')
	AND REFERENCED_OBJECT_ID = OBJECT_ID('ROLE_MSTR')
	AND	TYPE = 'F'
--SELECT @keyName

IF @keyName IS NOT NULL
	EXEC('ALTER TABLE [dbo].[ROLE_SEC_RIGHT]	DROP  CONSTRAINT [' + @keyName + ']')

SELECT @keyName = NULL
SELECT @keyName = NAME
FROM	SYS.FOREIGN_KEYS 
WHERE	PARENT_OBJECT_ID = OBJECT_ID('ROLE_USERS')
	AND REFERENCED_OBJECT_ID = OBJECT_ID('ROLE_MSTR')
	AND	TYPE = 'F'
--SELECT @keyName

IF @keyName IS NOT NULL
	EXEC('ALTER TABLE [dbo].[ROLE_USERS]	DROP  CONSTRAINT [' + @keyName + ']')

SELECT @keyName = NULL
SELECT @keyName = NAME
FROM	SYS.FOREIGN_KEYS 
WHERE	PARENT_OBJECT_ID = OBJECT_ID('WORKLIST_GROUP_ROLES')
	AND REFERENCED_OBJECT_ID = OBJECT_ID('ROLE_MSTR')
	AND	TYPE = 'F'
--SELECT @keyName

IF @keyName IS NOT NULL
	EXEC('ALTER TABLE [dbo].[WORKLIST_GROUP_ROLES]	DROP  CONSTRAINT [' + @keyName + ']')

SELECT @keyName = NULL
SELECT @keyName = NAME
FROM	SYS.FOREIGN_KEYS 
WHERE	PARENT_OBJECT_ID = OBJECT_ID('WORKLIST_ROLES')
	AND REFERENCED_OBJECT_ID = OBJECT_ID('ROLE_MSTR')
	AND	TYPE = 'F'
--SELECT @keyName

IF @keyName IS NOT NULL
	EXEC('ALTER TABLE [dbo].[WORKLIST_ROLES]	DROP  CONSTRAINT [' + @keyName + ']')

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE NAME = 'FK_HUB_MSG_DISTRIBUTION_ROLE_ID')
	ALTER TABLE [dbo].[HUB_MSG_DISTRIBUTION]	DROP  CONSTRAINT [FK_HUB_MSG_DISTRIBUTION_ROLE_ID]
IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE NAME = 'FK_ROLE_REPORTS_ROLE_MSTR')
	ALTER TABLE [dbo].[ROLE_REPORTING]			DROP  CONSTRAINT [FK_ROLE_REPORTS_ROLE_MSTR] 
IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE NAME = 'FK_ROLE_SCHED_DEPT_ROLE_ID')
	ALTER TABLE [dbo].[ROLE_SCHED_DEPTS]		DROP  CONSTRAINT [FK_ROLE_SCHED_DEPT_ROLE_ID] 
IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE NAME = 'FK_WEB_ROLE_REPORTS_ROLE_ID')
	ALTER TABLE [dbo].[WEB_ROLE_REPORTS]		DROP  CONSTRAINT [FK_WEB_ROLE_REPORTS_ROLE_ID] 
IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE NAME = 'FK_WEB_ROLE_RIGHT_ROLE_ID')
	ALTER TABLE [dbo].[WEB_ROLE_RIGHT]			DROP  CONSTRAINT [FK_WEB_ROLE_RIGHT_ROLE_ID] 
GO

/*
** Now, create a new table without a seeded identity.
** Copy off the current role_mstr data into a backup table.
** Drop the original and add the new.
*/
IF NOT EXISTS (SELECT * FROM SYS.OBJECTS WHERE NAME = 'ROLE_MSTR2')
BEGIN
	RAISERROR('			Creating new ROLE_MSTR table...', 0, 1) WITH NOWAIT
	CREATE TABLE [dbo].[ROLE_MSTR2](
		[ROLE_ID] [dbo].[ROLE_ID] NOT NULL,
		[NAME] [varchar](60) NOT NULL,
		[DESCRIPTION] [dbo].[DESCRIPTION] NULL,
		[ENABLE_FLG] [dbo].[BOOL] NULL,
	PRIMARY KEY CLUSTERED 
	(
		[ROLE_ID] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY],
	UNIQUE NONCLUSTERED 
	(
		[NAME] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
	) ON [PRIMARY]
END


IF NOT EXISTS (SELECT * FROM SYS.OBJECTS WHERE NAME = 'ROLE_MSTR_backup')
BEGIN
	CREATE TABLE ROLE_MSTR_backup
	(
		ROLE_ID INT NOT NULL,
		NAME VARCHAR(60) NULL,
		[DESCRIPTION] VARCHAR(32) NULL--,
		--[ENABLE_FLG] TINYINT NULL
	)
	
	INSERT INTO ROLE_MSTR_backup([ROLE_ID], [NAME], [DESCRIPTION])
		SELECT [ROLE_ID], [NAME], [DESCRIPTION]--, [ENABLE_FLG]
		FROM ROLE_MSTR
END
GO

IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE NAME = 'ROLE_MSTR2') AND (SELECT COUNT(*) FROM ROLE_MSTR2) = 0
BEGIN
	RAISERROR('			Removing ROLE_MSTR from any replication publications...', 0, 1) WITH NOWAIT
	EXEC DROP_ARTICLE 'ROLE_MSTR'
END
GO

IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE NAME = 'ROLE_MSTR2') AND (SELECT COUNT(*) FROM ROLE_MSTR2) = 0
BEGIN
	RAISERROR('			Switching data to new ROLE_MSTR table...', 0, 1) WITH NOWAIT
	--ALTER TABLE [ROLE_MSTR] SWITCH TO [ROLE_MSTR2]
	INSERT INTO ROLE_MSTR2([ROLE_ID], [NAME], [DESCRIPTION])--, [ENABLE_FLG])
		SELECT [ROLE_ID], [NAME], [DESCRIPTION] /*, [ENABLE_FLG]*/ FROM ROLE_MSTR
END

IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE NAME = 'ROLE_MSTR2') AND EXISTS (SELECT * FROM SYS.OBJECTS WHERE NAME = 'ROLE_MSTR')
BEGIN
	RAISERROR('			Checking transfer...', 0, 1) WITH NOWAIT
	IF (SELECT COUNT(*) FROM [ROLE_MSTR2]) = (SELECT COUNT(*) FROM [ROLE_MSTR_backup])
	BEGIN
		RAISERROR('			Dropping old ROLE_MSTR table (necessary for migration, a backup copy of data does exist - ROLE_MSTR_backup)...', 0, 1) WITH NOWAIT
		DROP TABLE [dbo].[ROLE_MSTR]

		RAISERROR('			Renaming old ROLE_MSTR2 table to ROLE_MSTR ...', 0, 1) WITH NOWAIT
		EXEC sys.sp_rename 'ROLE_MSTR2', 'ROLE_MSTR', 'OBJECT';

		RAISERROR('     Altering ROLE_MSTR successful.', 0, 1) WITH NOWAIT
	END
	ELSE
	BEGIN
		RAISERROR('ERROR: Data transfer to new table UNSUCCESSFUL!!!', 0, 1) WITH NOWAIT
	END
END
GO

RAISERROR('			Adding foreign keys back for ROLE_MSTR...', 0, 1) WITH NOWAIT
IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_HUB_MSG_DISTRIBUTION_ROLE_ID')
BEGIN
	ALTER TABLE [dbo].[HUB_MSG_DISTRIBUTION]  WITH CHECK ADD CONSTRAINT [FK_HUB_MSG_DISTRIBUTION_ROLE_ID] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO

IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_ROLE_REPORTS_ROLE_MSTR')
BEGIN
	ALTER TABLE [dbo].[ROLE_REPORTING]  WITH CHECK ADD CONSTRAINT [FK_ROLE_REPORTS_ROLE_MSTR] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO

IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_ROLE_SCHED_DEPT_ROLE_ID')
BEGIN
	ALTER TABLE [dbo].[ROLE_SCHED_DEPTS]  WITH NOCHECK ADD  CONSTRAINT [FK_ROLE_SCHED_DEPT_ROLE_ID] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO

IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_ROLE_SEC_RIGHT_ROLE_MSTR')
BEGIN
	ALTER TABLE [dbo].[ROLE_SEC_RIGHT]  WITH CHECK ADD CONSTRAINT [FK_ROLE_SEC_RIGHT_ROLE_MSTR] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO

IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_ROLE_USERS_ROLE_MSTR')
BEGIN
	ALTER TABLE [dbo].[ROLE_USERS]	WITH CHECK ADD CONSTRAINT [FK_ROLE_USERS_ROLE_MSTR] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO

IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_WEB_ROLE_REPORTS_ROLE_ID')
BEGIN
	ALTER TABLE [dbo].[WEB_ROLE_REPORTS]  WITH NOCHECK ADD  CONSTRAINT [FK_WEB_ROLE_REPORTS_ROLE_ID] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO

IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_WEB_ROLE_RIGHT_ROLE_ID')
BEGIN
	ALTER TABLE [dbo].[WEB_ROLE_RIGHT]  WITH NOCHECK ADD CONSTRAINT [FK_WEB_ROLE_RIGHT_ROLE_ID] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO

IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_WORKLIST_GROUP_ROLES_ROLE_MSTR')
BEGIN
	ALTER TABLE [dbo].[WORKLIST_GROUP_ROLES]  WITH CHECK ADD CONSTRAINT [FK_WORKLIST_GROUP_ROLES_ROLE_MSTR] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO

IF NOT EXISTS (SELECT * FROM SYSOBJECTS WHERE NAME = 'FK_WORKLIST_ROLES_ROLE_MSTR')
BEGIN
	ALTER TABLE [dbo].[WORKLIST_ROLES]  WITH CHECK ADD CONSTRAINT [FK_WORKLIST_ROLES_ROLE_MSTR] FOREIGN KEY([ROLE_ID])
	REFERENCES [dbo].[ROLE_MSTR] ([ROLE_ID])
END
GO


EXEC DROP_ARTICLE 'HUB_MSG_DISTRIBUTION'
EXEC DROP_ARTICLE 'ROLE_MSTR'
EXEC DROP_ARTICLE 'ROLE_REPORTING'
EXEC DROP_ARTICLE 'ROLE_SCHED_DEPTS'
EXEC DROP_ARTICLE 'ROLE_SEC_RIGHT'
EXEC DROP_ARTICLE 'ROLE_USERS'
EXEC DROP_ARTICLE 'WEB_ROLE_REPORTS'
EXEC DROP_ARTICLE 'WEB_ROLE_RIGHT'
EXEC DROP_ARTICLE 'WORKLIST_GROUP_ROLES'
EXEC DROP_ARTICLE 'WORKLIST_ROLES'

IF (SELECT SYSTEM_TYPE_ID FROM SYS.COLUMNS WHERE NAME = 'ROLE_ID' AND OBJECT_ID = OBJECT_ID('ROLE_MSTR')) = 167
BEGIN
	RAISERROR ('END NS-111907 - ROLE_ID migration has already been performed, do not run additional migrations!!!', 0, 1) WITH NOWAIT
END
ELSE
BEGIN
	IF (SELECT IS_IDENTITY FROM SYS.COLUMNS WHERE NAME = 'ROLE_ID' AND OBJECT_ID = OBJECT_ID('ROLE_MSTR')) = 0
		RAISERROR ('END NS-111907 - PRE-UDT PRODUCTION script complete. If no errors are evident, the migration process can now be executed.', 0, 1) WITH NOWAIT
	ELSE
		RAISERROR ('END NS-111907 - PRE-UDT PRODUCTION script completed but was unsuccessful, no database updates made. Please see errors and take actions as necessary.', 0, 1) WITH NOWAIT
END
GO


