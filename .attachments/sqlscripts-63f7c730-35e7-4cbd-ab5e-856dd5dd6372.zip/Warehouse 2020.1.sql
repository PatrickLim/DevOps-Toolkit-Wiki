set nocount on
go

If exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Timer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[Timer]
GO

CREATE PROCEDURE dbo.Timer (@input varchar(90)= '', @start int = 0) AS
declare @t datetime
declare @e datetime
declare @ret varchar(110)
/* Timer function Displays difference in time 'hh:mm:ss:%%%% (% as millisec)
            Timer 'Message', iStart 
            0 = Get difference (default) Display Message
            1 = Kill Timer Display Total time.
            2 = Init Timer 
            Note: Your script will display error messages BEFORE the cmd that generated the errors.
*/
	if (@Start = 0)
            begin
                        Select @t = (Select StartTime from Start)
                        select @e = GetDate() - @t
                        select @ret = Convert(varchar(20), @e,14) + ' ' + @input
                        Update Start set StartTime = GetDate(), Message = @input where StartTime = @t
                        print @ret
            end
            if (@Start = 1) 
            begin    
                        if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Start]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
                        begin
                                    Select @t = (Select CreateTime from Start)
                                    Select @e = GetDate()-@t
                                    select @ret = Convert(varchar(20), @e,14) + ' Total Upgrade time'
                                    print @ret
                                    drop table dbo.Start
                        end
            end
            if (@Start = 2)
            begin
						if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Start]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
                        begin
							drop table dbo.Start
                        end
                        
                        Create Table dbo.Start
                        (StartTime datetime,
                        Message VarChar(90),
                        CreateTime dateTime)
                        
                        Insert into Start values(GetDate(), 'Timer Started', GetDate())
            end
GO
 
Timer '', 2
go

print 'Current SQL Version: ' + char(13) +  @@Version
go


---------------------------
--                       --
--	UTILITY          --
--                       --
---------------------------
If exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[APPEND_COLUMN]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	Drop Procedure APPEND_COLUMN
GO

Create Procedure [dbo].APPEND_COLUMN (
		@table varchar (255),
		@column varchar (255),
		@type varchar (255),
		@nullable int,
		@default varchar(255) = ''
) AS
-- table = name of table to modify
-- column = column name to add
-- type = new column datatype as string
-- nullable = 1 (NULL), 0 (NOT NULL)
--
-- make sure table exists
If Exists (Select * From dbo.sysobjects o Inner Join syscolumns c On o.id = c.id Where o.id = Object_Id(@table) And ObjectProperty(o.id, N'IsUserTable') = 1)
BEGIN
	-- and column to add doesn't
	If Not Exists (Select * From dbo.sysobjects o Inner Join syscolumns c On o.id = c.id Where o.id = Object_Id(@table) And ObjectProperty(o.id, N'IsUserTable') = 1 And c.name = @column)
	BEGIN
		RAISERROR ('* %s, %s', 0, 1, @table, @column) WITH NOWAIT
		Declare @string varchar(8000)
		Set @string = 'ALTER TABLE dbo.' + @table + ' ADD ' + @column + ' ' + @type + ' '
		If @nullable <> 1
			Set @string = @string + ' NOT '
		Set @string = @string + ' NULL'
		if @default is null or @default = ''
			set @string = @string
		else
			set @string = @string + ' CONSTRAINT DF_' + @table + '_' + @column + ' DEFAULT ' + @default
		Exec (@string)
	END
	ELSE
	BEGIN
		RAISERROR ('Column %s already exists in table %s.',0,1,@column,@table) WITH NOWAIT
	END
END
ELSE
BEGIN
	RAISERROR ('Table %s does exist.',0,1,@table) WITH NOWAIT
END
GO

/*
** This will not work on columns that are a part of a key without dropping the constraints!!!
*/
If exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CHANGE_COLUMN_TYPE]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	Drop Procedure CHANGE_COLUMN_TYPE
GO

Create Procedure [dbo].CHANGE_COLUMN_TYPE (
		@table varchar (255),
		@column varchar (255),
		@newtype varchar (255),
		@nullable int
) AS

	/*
	** Declare our locals...
	*/
	declare @TableId 	as int
	declare @NewUserType 	as smallint
	declare @OldUserType 	as smallint
	declare @NullableStr 	as varchar(255)
	declare @TypeCheck as smallint
	
	/*
	** Default to NULLable if nothing given, otherwise, it's BOOLEAN (1=NULLable, 0 = NOT NULLable)...
	*/
	if @nullable <> 1 and @nullable is not NULL
		set @NullableStr = ' NOT NULL'
	else	
		set @NullableStr = ' NULL'
	
	print ''
	print 'Attempting to update column ' + @column + ' in the ' + @table + ' table with the new column type **' + @newtype + '**.'
	
	/*
	** Grab the types for the old and new columns...
	*/
	select @TableId=id from sysobjects where name = @table and xtype='U'
	
	select 	@OldUserType = usertype
	from 	syscolumns
	where 	name = @column and id = @TableId
	
	select 	@NewUserType = usertype
	from 	systypes
	where 	name = @newtype
	
	/*
	** Ensure the type exists...
	*/
	if @NewUserType is NULL
	begin
		raiserror ('     The user type **%s** could not be located. Table %s will not be updated.', 11, 1, @newtype, @table)
	end
	else
	begin
		
		/*
		** Check to see if the type has already been set, if so, leave as-is...
		*/
		if @OldUserType = @NewUserType
		begin
			 print '     The current type is **' + @newtype +'**, no update necessary.'
		end
		else
		begin
			/*
			** Update and verify...
			*/
			print ('     Executing: ALTER TABLE ' + @table + ' ALTER COLUMN ' + @column + ' ' + @newtype + @NullableStr)
			exec  ('ALTER TABLE ' + @table + ' ALTER COLUMN ' + @column + ' ' + @newtype + @NullableStr)
	
			select 	@TypeCheck = usertype
			from 	syscolumns
			where 	name = @column and id = @TableId
	
			if @TypeCheck <> @NewUserType
			begin
				print ''
				raiserror ('     The user type **%s** was not successfully assigned to the %s table!', 11, 1, @newtype, @table)
			end
			else
			begin
				print @table + ' table updated successfully with new type.'
			end
		end
	end

	print ''
GO

-- <INSERT SCRIPTS BELOW> --

-- <INSERT SCRIPTS ABOVE> --

go
timer 'Updates Complete'
go
If exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[APPEND_COLUMN]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	Drop Procedure dbo.APPEND_COLUMN
GO

DROP PROCEDURE dbo.CHANGE_COLUMN_TYPE
GO

-- Version Update for the warehouse database
RAISERROR ('Updating Version data',0,1) WITH NOWAIT
GO

declare @VERSION varchar(6)
declare @BUILD varchar(6)
declare @RELEASE varchar(30)

Select @VERSION = '2020.1'
Select @BUILD = '1' --Insert Date in YYMMDD when moving to Patch
Select @RELEASE = '2020.1.BI-0'

RAISERROR ('Inserted release: %s build %s ', 0, 1, @RELEASE, @BUILD)

Insert Into Version Select @VERSION, @BUILD, 
getdate(), suser_sname(), host_name(), 'ICS Warehouse Database @ ' + @RELEASE + ' Build ' + @BUILD
go

DECLARE @database_name varchar(255)
SET @database_name = db_name()
RAISERROR ('Inserted into: %s database',0,1,@database_name)
GO

Timer '', 1
go

DECLARE @date varchar(255)
SET @date = CONVERT(VARCHAR,GETDATE())
RAISERROR ('Script complete: %s',0,1,@date) WITH NOWAIT
GO

Set Nocount Off
GO

